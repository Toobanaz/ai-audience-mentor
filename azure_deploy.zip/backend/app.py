from flask import Flask, request, jsonify
from flask_cors import CORS
import azure.cognitiveservices.speech as speechsdk
from pydub import AudioSegment, silence
import openai
import time
import os
import traceback
from openai import AzureOpenAI
from flask import send_from_directory
import os

app = Flask(__name__)
CORS(app)  # Allow frontend to call the backend

# Azure Speech
SPEECH_KEY = "DN9sJDTwszwARhRJsodK9ghq0zqsELDFsueMK1MqSCoUdXWx3g3eJQQJ99BDAC5T7U2XJ3w3AAAEACOGeQlJ"
SPEECH_ENDPOINT = "https://neuralnomads-hackathon-stg-frc-ais-01.cognitiveservices.azure.com/"
REGION = "francecentral"

# Azure OpenAI
openai.api_type = "azure"
openai.api_base = "https://neuralnomads-hackathon-stg-aoai-sc-01.openai.azure.com/"
openai.api_version = "2023-05-15"
openai.api_key = "8FxgCGfQiPPExro4qLQwqLerfydkU3CMXzZ0AJpANWnqYrqI3dmMJQQJ99BDACfhMk5XJ3w3AAABACOGvOS6"
GPT_DEPLOYMENT_NAME = "gpt-35-turbo"

@app.route("/analyze", methods=["POST"])
def analyze_audio():
    try:
        print("FILES RECEIVED:", request.files) 
        # === Instead of uploaded file, use tareq_test.wav from your workspace ===
        audio_file = request.files["audio"]
        file_path = "tareq_test.wav"  # Directly use your local file
        audio_file.save(file_path)
        print("File saved to:", file_path)
        # Detect silence
        audio = AudioSegment.from_wav(file_path)
        silent_ranges = silence.detect_silence(audio, min_silence_len=1000, silence_thresh=-40)
        silent_ranges = [(start / 1000, end / 1000) for start, end in silent_ranges]
        print("Detected silent ranges:", silent_ranges)
        # Transcription
        def transcribe():
            done = False
            all_text = []

            def final_result(evt):
                all_text.append(evt.result.text)

            def stop_cb(evt): nonlocal done; done = True

            speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, endpoint=SPEECH_ENDPOINT)
            audio_config = speechsdk.audio.AudioConfig(filename=file_path)
            recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

            recognizer.recognized.connect(final_result)
            recognizer.session_stopped.connect(stop_cb)
            recognizer.canceled.connect(stop_cb)

            recognizer.start_continuous_recognition()
            while not done:
                time.sleep(0.5)
            recognizer.stop_continuous_recognition()

            return " ".join(all_text)

        original_transcript = transcribe()
        
        # Insert silence markers
        words = original_transcript.split()
        words_per_second = 2
        estimated_word_times = [(i / words_per_second) for i in range(len(words))]
        for start, end in silent_ranges:
            for i, word_time in enumerate(estimated_word_times):
                if abs(word_time - start) < 0.5:
                    words.insert(i, "[silence]")
                    break

        final_transcript = " ".join(words)

        # GPT Feedback
        system_prompt = """
You are an AI presentation coach. Your role is to analyze a student's speech transcript from a presentation and provide clear, constructive feedback to help them improve their delivery.

You must:
- Detect and comment on the use of filler words such as um, uh, like, you know, so, etc.
- Identify occurrences of [silence] in the transcript and interpret them as moments of hesitation, awkward pauses, or nervousness.
- Recognize signs of poor structure, repetition, or lack of confidence in the speech.
- Give actionable advice such as:
  - Reducing filler words
  - Rehearsing to avoid pauses
  - Improving clarity and confidence
  - Using better transitions or structuring ideas


Tone:
- Be friendly and approachable, as if you are a supportive coach.
- Be supportive, motivational, and professional.
- Balance your critique with encouragement and tips for improvement.

After giving feedback, also generate 3 thoughtful questions related to the content of the transcript to test the student's knowledge and critical thinking about their presentation topic.
"""
        client = AzureOpenAI(
    api_key=openai.api_key,
    api_version=openai.api_version,
    azure_endpoint=openai.api_base
    )
        response = client.chat.completions.create(
        model=GPT_DEPLOYMENT_NAME,
        messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Here is the transcript:\n\n{final_transcript}"}
        ]
    )


        result = response.choices[0].message.content
        return jsonify({
            "transcript": final_transcript,
            "feedback": result
        })

    except Exception as e:
        print("🔥 Exception:", str(e))
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    
@app.route('/')
@app.route('/<path:path>')
def serve_react(path=''):
    if path != "" and os.path.exists("dist/" + path):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')



if __name__ == "__main__":
    app.run(debug=True)
